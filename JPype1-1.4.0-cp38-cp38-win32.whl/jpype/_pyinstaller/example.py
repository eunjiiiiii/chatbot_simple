import jpype

print('+++ about to start JVM')
jpype.startJVM()
print('+++ JVM started')
